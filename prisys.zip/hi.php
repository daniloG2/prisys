<div class="col-sm-12 text-center">
	<h2>Bienvenido Amigo Sentenciado</h2>
	<h1>:(</h1>
</div>